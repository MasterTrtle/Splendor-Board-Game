var searchData=
[
  ['partie_0',['Partie',['../class_splendor_1_1_partie.html',1,'Splendor']]],
  ['pile_1',['Pile',['../classmateriel_1_1_pile.html',1,'materiel']]],
  ['pioche_2',['Pioche',['../classmateriel_1_1_pioche.html',1,'materiel']]],
  ['plateau_3',['Plateau',['../class_splendor_1_1_plateau.html',1,'Splendor']]],
  ['prix_4',['Prix',['../classmateriel_1_1_prix.html',1,'materiel']]]
];
