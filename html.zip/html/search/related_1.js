var searchData=
[
  ['iterator_0',['Iterator',['../class_splendor_1_1_partie.html#a9830fc407400559db7e7783cc10a9394',1,'Splendor::Partie']]]
];
