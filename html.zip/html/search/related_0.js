var searchData=
[
  ['controleur_0',['Controleur',['../class_splendor_1_1_joueur.html#a459e0c467ba9f78671640ae72d171b07',1,'Splendor::Joueur::Controleur()'],['../class_splendor_1_1_regles.html#a459e0c467ba9f78671640ae72d171b07',1,'Splendor::Regles::Controleur()']]]
];
