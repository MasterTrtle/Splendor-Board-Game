var searchData=
[
  ['jetons_0',['jetons',['../classmateriel_1_1_pile.html#a13924eab248b0402177fbe404a87e8d3',1,'materiel::Pile::jetons()'],['../class_splendor_1_1_partie.html#a262298f382c41b170e9859b530484568',1,'Splendor::Partie::jetons()']]],
  ['joueurs_1',['joueurs',['../class_splendor_1_1_controleur.html#a8f788d82c409bd742605f827b9721723',1,'Splendor::Controleur']]]
];
