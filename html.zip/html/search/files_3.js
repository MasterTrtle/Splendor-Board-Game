var searchData=
[
  ['splendor_2ecpp_0',['splendor.cpp',['../splendor_8cpp.html',1,'']]],
  ['splendor_2eh_1',['splendor.h',['../splendor_8h.html',1,'']]]
];
