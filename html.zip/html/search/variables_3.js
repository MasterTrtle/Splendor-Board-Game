var searchData=
[
  ['handler_0',['handler',['../class_splendor_1_1_partie.html#a5d80ad0cc1008f1bbe328a31fcb56cc5',1,'Splendor::Partie']]]
];
