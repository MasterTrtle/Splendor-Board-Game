var searchData=
[
  ['next_0',['next',['../class_splendor_1_1_partie_1_1_iterator.html#a66a1d9304d978712755ab1b82293c397',1,'Splendor::Partie::Iterator::next()'],['../class_splendor_1_1_partie_1_1_iterator_jeton.html#a7a99c02cb0269cace0b60ccb4a05f1c3',1,'Splendor::Partie::IteratorJeton::next()']]]
];
