var indexSectionsWithContent =
{
  0: "_abcdeghijlmnoprstuv~",
  1: "cghijmprsv",
  2: "msu",
  3: "gmosv",
  4: "acdeghijlmnoprsv~",
  5: "bcghijnprtuv",
  6: "j",
  7: "ct",
  8: "abjnprv",
  9: "cipr",
  10: "_l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros"
};

