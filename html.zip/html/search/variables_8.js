var searchData=
[
  ['reduction_0',['reduction',['../class_splendor_1_1_joueur.html#a8ad29c6f8f6a1a241dd47209c4818bf2',1,'Splendor::Joueur']]],
  ['reserved_1',['Reserved',['../class_splendor_1_1_joueur.html#a68625d52b220840cf99676582694ed3d',1,'Splendor::Joueur']]],
  ['rouge_2',['rouge',['../classmateriel_1_1_prix.html#ad117271598efcb37f19832685753cec1',1,'materiel::Prix']]]
];
