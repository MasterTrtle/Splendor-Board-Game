var searchData=
[
  ['handler_0',['Handler',['../struct_splendor_1_1_partie_1_1_handler.html',1,'Splendor::Partie']]]
];
