var searchData=
[
  ['splendorexception_0',['SplendorException',['../class_splendor_1_1_splendor_exception.html',1,'Splendor']]]
];
