var searchData=
[
  ['regles_0',['Regles',['../class_splendor_1_1_regles.html#a0d762dd6c5a9c7f118cf2c77defca537',1,'Splendor::Regles']]],
  ['remplir_1',['remplir',['../classmateriel_1_1_pile.html#aecd530147ec28b9a3c054c994a2cddca',1,'materiel::Pile']]],
  ['reservercarte_2',['reserverCarte',['../class_splendor_1_1_controleur.html#a94d47186d8aa6864ab9626b10daae04d',1,'Splendor::Controleur']]],
  ['retirerjeton_3',['retirerJeton',['../classmateriel_1_1_pile.html#a25c1bc3e8077092c9f33c55a200d047e',1,'materiel::Pile']]]
];
