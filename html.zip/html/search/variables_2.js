var searchData=
[
  ['game_0',['game',['../classgame__setting.html#a0c10765a15d89afb538b2ca59d4f528f',1,'game_setting']]],
  ['gamesetting_1',['gameSetting',['../class_main_window.html#a466ea2b5497a0346add2bdc142d536c7',1,'MainWindow']]]
];
