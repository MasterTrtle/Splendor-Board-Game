var searchData=
[
  ['handler_0',['Handler',['../struct_splendor_1_1_partie_1_1_handler.html#add66467dc551846526a2289e4b1aa23e',1,'Splendor::Partie::Handler']]]
];
