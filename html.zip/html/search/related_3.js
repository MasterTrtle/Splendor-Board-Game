var searchData=
[
  ['regles_0',['Regles',['../class_splendor_1_1_controleur.html#afc175d6bb976ea6fdb67c42d236ae431',1,'Splendor::Controleur']]]
];
