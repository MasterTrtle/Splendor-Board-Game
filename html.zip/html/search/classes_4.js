var searchData=
[
  ['jeton_0',['Jeton',['../classmateriel_1_1_jeton.html',1,'materiel']]],
  ['joueur_1',['Joueur',['../class_splendor_1_1_joueur.html',1,'Splendor']]]
];
