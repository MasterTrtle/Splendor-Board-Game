var searchData=
[
  ['distribuercarte_0',['distribuerCarte',['../class_splendor_1_1_controleur.html#a12dd4b530b441e0cabb5735096506ef8',1,'Splendor::Controleur']]],
  ['donner2jetons_1',['donner2jetons',['../class_splendor_1_1_controleur.html#a8a36e313cf871a7eb7a24bbec8ac5ea8',1,'Splendor::Controleur']]],
  ['donner3jetons_2',['donner3jetons',['../class_splendor_1_1_controleur.html#ae23a8c553f36508844bd7bb15aceab52',1,'Splendor::Controleur']]],
  ['donnerjeton_3',['donnerJeton',['../class_splendor_1_1_controleur.html#a34ec71358fcfb362d5e337ebc2bd523e',1,'Splendor::Controleur']]]
];
