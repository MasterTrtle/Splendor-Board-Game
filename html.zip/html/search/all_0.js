var searchData=
[
  ['_5fsplendor_5fh_0',['_SPLENDOR_H',['../splendor_8h.html#a475cfc3becc4b8c44cd9c4fd3b320069',1,'splendor.h']]]
];
