var searchData=
[
  ['game_5finterface_0',['game_interface',['../classgame__interface.html',1,'']]],
  ['game_5fsetting_1',['game_setting',['../classgame__setting.html',1,'']]]
];
