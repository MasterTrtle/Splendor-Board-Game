var searchData=
[
  ['regles_0',['Regles',['../class_splendor_1_1_regles.html',1,'Splendor']]]
];
